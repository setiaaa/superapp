//HomeBottomTabs.js
import React, { useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import BottomTabNavigator from "../components/BottomTabNavigator";
import HomeTab from "./tabs/HomeTab";
import DashboardTab from "./tabs/DashboardTab";

const tabs = [
  { name: "Beranda", icon: "home", component: HomeTab },
  { name: "Dashboard", icon: "home", component: DashboardTab },
//   { name: "Akun", icon: "account", component: AkunTab },
];
const HomeTabs = () => {
  return <BottomTabNavigator tabs={tabs} />;
};

const styles = StyleSheet.create({
});

export default HomeTabs;
